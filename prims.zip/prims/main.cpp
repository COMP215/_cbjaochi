//
//  main.cpp
//  Project_1
//
//  Created by Christian Joachim on 9/19/16.
//  Copyright © 2016 Christian Joachim. All rights reserved.
//

#include <iostream>
#include "node.h"
#include <ctime>

int main()
{
    Node S;
    
    S.add_node(4);
    S.add_node(3);
    S.add_node(5);
    S.add_node(6);
    S.add_node(9);
    
    
    
    
    
    
    
    
    
    
    
    
}

