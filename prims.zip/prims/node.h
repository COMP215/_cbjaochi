//
//  node.h
//  Project_1
//
//  Created by Christian Joachim on 9/19/16.
//  Copyright © 2016 Christian Joachim. All rights reserved.
//

#ifndef node_h
#define node_h



class Node
{
public:
    Node();
    Node* first;
    Node* last;
    void add_node(int data);
    Node* new_node;
    int info;
    Node* link;
private:
    
    
    
    
    
};


#endif /* node_h */
