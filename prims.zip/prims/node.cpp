//
//  node.cpp
//  Project_1
//
//  Created by Christian Joachim on 9/19/16.
//  Copyright © 2016 Christian Joachim. All rights reserved.
//

#include "node.h"
#include <iostream>
using namespace std;


Node::Node()
{
    first = NULL;
    last  = NULL;
    
}

void Node::add_node(int data)

{
    new_node = new Node;
    
    new_node->info = data;
    new_node->link = NULL;
    
    if (first == NULL)
    {
        first = new_node;
        last  = new_node ;
        cout << "the starting value is " << new_node->info << endl;
    }else
    {
        last->link = new_node;
        last = new_node;
        cout << "the next value is " << new_node->info << endl;
        
    }
    
        
    
}


